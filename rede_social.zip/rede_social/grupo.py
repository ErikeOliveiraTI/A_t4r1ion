class Grupo:
    def __init__(self,nome, categoria,admin=None):
        self.nome = nome
        self.categoria = categoria
        self.membros =[]





