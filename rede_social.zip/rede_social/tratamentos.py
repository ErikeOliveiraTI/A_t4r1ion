class IdadeMenorException(Exception):
    pass
class ContaExistenteException(Exception):
    pass

class UsuarioExistenteException(Exception):
    pass

class NomeMaiorexception(Exception):
    pass